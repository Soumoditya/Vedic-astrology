# Vedic Astrology Consultation — Booking Site

A modern, single-page booking site for Vedic astrology consultations. Built with Next.js 14, Tailwind, and Framer Motion. Deploys to Vercel free tier from a GitHub repo, stores bookings in a Google Sheet via Apps Script.

**Stack:** Next.js 14 (App Router) · Tailwind · Framer Motion · Google Apps Script (no backend hosting needed)

**What it does:**
- Visitors browse the site, pick a plan (₹1,500 full reading or ₹500/topic stackable)
- They fill in birth details + context, pay via your UPI QR / UPI ID
- They enter their UTR (transaction reference) from their UPI app
- Booking + UTR is logged into your Google Sheet, you get an email
- You verify the UTR against your Jio Payments Bank app, deliver the reading on Reddit DM

---

## Setup — Step by Step

### 1. Set up the Google Sheet (the "database")

a) Go to [sheets.google.com](https://sheets.google.com) → blank spreadsheet. Name it whatever (e.g. "Astro Bookings").

b) Click `Extensions → Apps Script`.

c) Delete whatever's in `Code.gs`. Open the file `scripts/apps-script.gs` from this repo. Copy its entire contents and paste into Apps Script.

d) Near the top, change:
```javascript
const NOTIFY_EMAIL = 'your-email@example.com';
```
to your own email. This is where booking notifications will go.

e) Click the disk icon to save. Name the project something like "Astro Booking API".

f) Click **Deploy → New deployment** → click the gear icon → choose **Web app**. Settings:
- Description: `Astro Booking endpoint`
- Execute as: **Me**
- Who has access: **Anyone**

Click **Deploy**. Authorize access when prompted (this is required because the script writes to your Sheet and sends mail from your account).

g) Copy the **Web app URL** that appears. It looks like:
```
https://script.google.com/macros/s/AKfycbz.../exec
```
You'll need this in step 3.

> **Future updates:** if you ever change the script, redeploy as a new version: Deploy → Manage deployments → pencil icon → Version: New version → Deploy.

### 2. Push to GitHub

a) On [github.com](https://github.com), create a new empty repo (e.g. `vedic-astro-site`). **Don't** initialize with README/license — keep it empty.

b) In this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vedic-astro-site.git
git push -u origin main
```

### 3. Deploy to Vercel

a) Go to [vercel.com](https://vercel.com) and sign in with your GitHub account (free tier is plenty).

b) Click **Add New → Project** → import the GitHub repo you just pushed.

c) On the import screen, expand **Environment Variables** and add:

| Name | Value |
|------|-------|
| `NEXT_PUBLIC_APPS_SCRIPT_URL` | the Web app URL from step 1g |

That's the only one strictly required — all others have defaults baked in.

If you ever change your UPI ID, account number, or IFSC, you can override:
- `NEXT_PUBLIC_UPI_ID`
- `NEXT_PUBLIC_PAYEE_NAME`
- `NEXT_PUBLIC_ACCOUNT_NUMBER`
- `NEXT_PUBLIC_IFSC`

d) Click **Deploy**. Wait ~1 minute. Done.

Your site is live at `your-project.vercel.app`. You can hook a custom domain (e.g. `soumodityapramanik.in/astro` or a subdomain) in Vercel → Settings → Domains.

---

## How payments work end-to-end

There's no Razorpay or payment gateway. Here's the actual flow:

1. User picks plan → fills details → reaches the **Payment** step.
2. They scan your QR or copy your UPI ID, pay the amount.
3. UPI app shows a success screen with a **UTR** (12-digit ref number).
4. They paste the UTR into the **Confirm** step, hit Submit.
5. The booking + UTR lands in your Google Sheet (status: `Pending Verification`). You get an email.
6. You open Jio Payments app, see the matching incoming credit, match the UTR.
7. You change the row's `Status` column in the Sheet to `Verified` (manually).
8. You read the chart, send the reading to the user's Reddit DM.

The whole thing is automated up to the verification step. Verification is the only "manual" piece — and it has to be, because there's no API access to a personal UPI account. You're trading 30 seconds of UTR-matching per booking for ₹0 in payment-gateway fees.

If a booking comes in with no UTR, the form blocks submission, so you'll never have a row in the Sheet without proof of payment. If someone enters a fake UTR, you simply won't find it in your Jio app — mark the row `Invalid UTR` and ignore.

---

## Local Development

```bash
# Copy env template
cp .env.example .env.local

# Edit .env.local — paste your Apps Script URL into NEXT_PUBLIC_APPS_SCRIPT_URL

npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## Customising the Site

All copy and pricing is in the component files. Most common edits:

| What | Where |
|------|-------|
| Pricing (₹1,500 / ₹500) | `app/components/Services.js` and `BookingModal.js` |
| Topic list | `app/components/Services.js` (the `TOPICS` array) |
| FAQ questions | `app/components/FAQ.js` |
| Reddit / Insta links | `app/components/Trust.js` and `Footer.js` |
| Site title / description | `app/layout.js` |
| Colors / fonts | `tailwind.config.mjs` |
| QR image | replace `public/upi-qr.jpg` with a new file (keep the same name) |

After any change, just `git push` — Vercel auto-redeploys.

---

## Project Structure

```
vedic-astro-site/
├── app/
│   ├── layout.js           # root layout, fonts, metadata
│   ├── page.js             # main page composition
│   ├── globals.css         # base styles, theme, custom utilities
│   ├── icon.svg            # favicon
│   └── components/
│       ├── Nav.js          # sticky top nav
│       ├── Hero.js         # hero section + cosmic ring
│       ├── Services.js     # pricing plans + topic list
│       ├── HowItWorks.js   # 4-step process
│       ├── Trust.js        # Reddit/Insta social proof
│       ├── FAQ.js          # collapsible questions
│       ├── Footer.js       # footer + final CTA
│       └── BookingModal.js # the entire 4-step booking flow
├── public/
│   └── upi-qr.jpg          # your UPI QR (replaceable)
├── scripts/
│   └── apps-script.gs      # Google Apps Script (paste into your Sheet)
├── package.json
├── next.config.mjs
├── tailwind.config.mjs
├── postcss.config.mjs
├── jsconfig.json
├── .env.example
├── .gitignore
└── README.md
```

---

## Notes

- **No tracking, no analytics.** Add one yourself if you want it (Vercel Analytics is one click on the project dashboard).
- **No accounts / login.** Bookings are stateless. The Reddit username is the only identifier.
- **Rate limiting** — Apps Script free tier handles ~20,000 calls/day, far more than you'll ever need.
- **Mobile UPI deep link** — on phones, the "Open UPI App" button auto-launches PhonePe / GPay / Paytm with the amount and recipient pre-filled.
