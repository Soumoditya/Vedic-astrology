'use client';
import { useState } from 'react';
import Nav from './components/Nav';
import Hero from './components/Hero';
import Services from './components/Services';
import HowItWorks from './components/HowItWorks';
import Trust from './components/Trust';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import BookingModal from './components/BookingModal';

export default function Page() {
  const [modalOpen, setModalOpen] = useState(false);
  const [initialPlan, setInitialPlan] = useState(null);

  const openBooking = (plan) => {
    setInitialPlan(plan === 'topics' || plan === 'full' ? plan : null);
    setModalOpen(true);
  };

  return (
    <main id="top" className="relative grain">
      <Nav onBookClick={() => openBooking()} />
      <Hero onBookClick={() => openBooking()} />
      <Services onBookClick={openBooking} />
      <HowItWorks />
      <Trust />
      <FAQ />
      <Footer onBookClick={() => openBooking()} />

      <BookingModal
        open={modalOpen}
        initialPlan={initialPlan}
        onClose={() => setModalOpen(false)}
      />
    </main>
  );
}
