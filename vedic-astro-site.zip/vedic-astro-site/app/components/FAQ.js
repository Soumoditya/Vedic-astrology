'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

const FAQS = [
  {
    q: 'How long until I get my reading?',
    a: 'Typically 24–48 hours after your payment is verified. Verification itself usually takes a few hours during the day. If you book overnight (IST), it may extend to the next day.',
  },
  {
    q: "What if I don't know my exact birth time?",
    a: "Birth time matters a lot in Vedic astrology — even a 5-minute difference can change the Lagna. If you're unsure, check your birth certificate or hospital records. If you only have an approximate time, mention it in the context box and I'll note the limitations in the reading.",
  },
  {
    q: 'Why Reddit DM and not email?',
    a: 'Reddit gives both of us a verifiable conversation thread tied to a public account. You can see my history, I can see yours. It also keeps everything off email, which I prefer for privacy.',
  },
  {
    q: 'Is my information private?',
    a: "Your birth details and questions are used only to read your chart. They're stored in my private records, never shared, never posted publicly. The reading itself is sent only to you.",
  },
  {
    q: 'How do I confirm payment without Razorpay?',
    a: 'After paying via UPI, your app gives you a UTR (Unique Transaction Reference) — a 12-digit number. Enter it in the booking form. I match it against the payment received in my Jio Payments account. No middleman, no payment gateway fees.',
  },
  {
    q: 'Can I ask follow-up questions?',
    a: "Yes — one round of clarifying questions is included with every reading. If you need a deeper look at a different topic later, that's a fresh ₹500 topic reading.",
  },
  {
    q: 'What approach do you follow?',
    a: "Classical Vedic astrology — Parāśara framework, with Lagna, navamsha, dashas, and yogas as the core. No westernised sun-sign predictions, no auto-generated PDF reports.",
  },
  {
    q: "What if the reading doesn't resonate?",
    a: 'Astrology is interpretive. If something genuinely seems off, message me on Reddit and we can discuss. I will not refund a delivered reading, but I will work with you to clarify or expand any part of it.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState(0);

  return (
    <section id="faq" className="relative py-32 md:py-40 px-6 md:px-12 bg-ink-soft/40">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-12 gap-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="col-span-12 md:col-span-3"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="block w-8 h-px bg-brass" />
              <span className="text-xs uppercase tracking-[0.3em] text-brass font-mono">
                04 / Questions
              </span>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="col-span-12 md:col-span-9 font-display text-4xl md:text-6xl font-light leading-[1.05] tracking-tight"
          >
            Things people<br />
            <span className="italic text-brass font-extralight">ask first.</span>
          </motion.h2>
        </div>

        <div className="space-y-2">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: i * 0.04 }}
                className="border-b border-ink-line"
              >
                <button
                  onClick={() => setOpen(isOpen ? -1 : i)}
                  className="w-full flex items-start justify-between gap-6 py-6 text-left group"
                >
                  <span className="font-display text-xl md:text-2xl font-light text-cream group-hover:text-brass transition-colors leading-tight">
                    {item.q}
                  </span>
                  <span
                    className={`text-brass text-2xl shrink-0 transition-transform duration-500 ${
                      isOpen ? 'rotate-45' : ''
                    }`}
                  >
                    +
                  </span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="text-cream/70 leading-relaxed pb-8 pr-12 max-w-3xl">
                        {item.a}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
