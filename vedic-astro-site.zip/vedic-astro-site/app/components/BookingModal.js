'use client';
import { motion, AnimatePresence } from 'framer-motion';
import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import { TOPICS } from './Services';

const UPI_ID = process.env.NEXT_PUBLIC_UPI_ID || '7601833023@ptyes';
const PAYEE_NAME = process.env.NEXT_PUBLIC_PAYEE_NAME || 'Vedic Astro Consultation';
const ACCOUNT_NUMBER = process.env.NEXT_PUBLIC_ACCOUNT_NUMBER || '003521714335964';
const IFSC = process.env.NEXT_PUBLIC_IFSC || 'JIOP0000001';
const APPS_SCRIPT_URL = process.env.NEXT_PUBLIC_APPS_SCRIPT_URL || '';

const STEPS = ['Plan', 'Details', 'Payment', 'Confirm'];

export default function BookingModal({ open, onClose, initialPlan }) {
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const [form, setForm] = useState({
    plan: 'full', // 'full' | 'topics'
    topics: [],
    name: '',
    redditUsername: '',
    email: '',
    gender: '',
    dob: '',
    tob: '',
    pob: '',
    context: '',
    questions: '',
    utr: '',
    feedback: '',
  });

  // Reset when reopened with initial plan
  useEffect(() => {
    if (open) {
      setStep(0);
      setSubmitted(false);
      setSubmitError('');
      if (initialPlan === 'topics' || initialPlan === 'full') {
        setForm((f) => ({ ...f, plan: initialPlan }));
      }
    }
  }, [open, initialPlan]);

  // Lock body scroll when open
  useEffect(() => {
    if (!open) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = original;
    };
  }, [open]);

  // Esc to close
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === 'Escape' && !submitting) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose, submitting]);

  const total = useMemo(() => {
    if (form.plan === 'full') return 1500;
    return form.topics.length * 500;
  }, [form.plan, form.topics]);

  const canProceedStep0 = form.plan === 'full' || (form.plan === 'topics' && form.topics.length > 0);

  const canProceedStep1 = useMemo(() => {
    return (
      /^[a-zA-Z0-9_-]{3,20}$/.test(form.redditUsername.replace(/^u\//, '')) &&
      form.gender &&
      form.dob &&
      form.tob &&
      form.pob.trim().length >= 3 &&
      form.context.trim().length >= 10
    );
  }, [form]);

  const canProceedStep2 = true; // user just clicks "I have paid"
  const canSubmit = form.utr.trim().length >= 8;

  const setField = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const toggleTopic = (id) => {
    setForm((f) => ({
      ...f,
      topics: f.topics.includes(id) ? f.topics.filter((t) => t !== id) : [...f.topics, id],
    }));
  };

  const upiLink = useMemo(() => {
    const params = new URLSearchParams({
      pa: UPI_ID,
      pn: PAYEE_NAME,
      am: String(total),
      cu: 'INR',
      tn: `Astro Reading - ${form.redditUsername || 'guest'}`,
    });
    return `upi://pay?${params.toString()}`;
  }, [total, form.redditUsername]);

  const handleSubmit = async () => {
    if (!canSubmit || submitting) return;
    setSubmitting(true);
    setSubmitError('');

    const topicsLabels = form.topics
      .map((id) => TOPICS.find((t) => t.id === id)?.label)
      .filter(Boolean);

    const payload = {
      timestamp: new Date().toISOString(),
      plan: form.plan === 'full' ? 'Full Birth Chart Reading' : 'Specific Topic Reading',
      topics: form.plan === 'topics' ? topicsLabels : [],
      amount: total,
      name: form.name.trim(),
      redditUsername: form.redditUsername.replace(/^u\//, '').trim(),
      email: form.email.trim(),
      gender: form.gender,
      dob: form.dob,
      tob: form.tob,
      pob: form.pob.trim(),
      context: form.context.trim(),
      questions: form.questions.trim(),
      utr: form.utr.trim(),
      feedback: form.feedback.trim(),
      status: 'Pending Verification',
    };

    try {
      if (!APPS_SCRIPT_URL) {
        throw new Error(
          'Booking endpoint not configured. Set NEXT_PUBLIC_APPS_SCRIPT_URL in your environment.'
        );
      }
      const res = await fetch(APPS_SCRIPT_URL, {
        method: 'POST',
        body: JSON.stringify(payload),
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      });
      // Apps Script may not return CORS headers; if no error thrown, treat as ok
      if (res && !res.ok && res.status !== 0) {
        throw new Error(`Server returned ${res.status}`);
      }
      setSubmitted(true);
    } catch (err) {
      setSubmitError(
        err.message ||
          'Could not submit booking. Take a screenshot of your details + UTR and message u/invincible-xd directly.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-stretch md:items-center justify-center"
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-ink/85 backdrop-blur-md"
            onClick={!submitting ? onClose : undefined}
          />

          {/* Modal */}
          <motion.div
            initial={{ y: 40, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 20, opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="relative w-full md:max-w-3xl bg-ink border border-ink-line md:rounded-2xl md:my-8 max-h-screen md:max-h-[90vh] flex flex-col overflow-hidden shadow-2xl"
          >
            {/* Header */}
            <div className="px-6 md:px-10 py-6 border-b border-ink-line flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <span className="font-display text-2xl text-brass font-light">ज्योतिष</span>
                <span className="text-cream-dim text-xs font-mono uppercase tracking-[0.2em] hidden sm:block">
                  Booking
                </span>
              </div>
              <button
                onClick={onClose}
                disabled={submitting}
                aria-label="Close"
                className="text-cream-dim hover:text-cream text-2xl leading-none p-1"
              >
                ×
              </button>
            </div>

            {/* Step indicator */}
            {!submitted && (
              <div className="px-6 md:px-10 py-4 border-b border-ink-line shrink-0">
                <div className="flex items-center gap-2 md:gap-4">
                  {STEPS.map((label, i) => (
                    <div key={label} className="flex items-center gap-2 md:gap-4 flex-1">
                      <div className="flex items-center gap-2 md:gap-3 min-w-0">
                        <span
                          className={`shrink-0 w-6 h-6 rounded-full border flex items-center justify-center text-[10px] font-mono transition-colors ${
                            i <= step
                              ? 'bg-brass border-brass text-ink'
                              : 'border-ink-line text-cream-dim'
                          }`}
                        >
                          {i + 1}
                        </span>
                        <span
                          className={`text-[10px] md:text-xs uppercase tracking-[0.2em] font-mono truncate ${
                            i <= step ? 'text-cream' : 'text-cream-dim'
                          }`}
                        >
                          {label}
                        </span>
                      </div>
                      {i < STEPS.length - 1 && (
                        <span
                          className={`flex-1 h-px transition-colors ${
                            i < step ? 'bg-brass' : 'bg-ink-line'
                          }`}
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Body */}
            <div className="flex-1 overflow-y-auto modal-scroll">
              {submitted ? (
                <SuccessScreen form={form} total={total} onClose={onClose} />
              ) : (
                <div className="px-6 md:px-10 py-8 md:py-10">
                  <AnimatePresence mode="wait">
                    {step === 0 && (
                      <StepWrap key="0">
                        <PlanStep form={form} setField={setField} toggleTopic={toggleTopic} total={total} />
                      </StepWrap>
                    )}
                    {step === 1 && (
                      <StepWrap key="1">
                        <DetailsStep form={form} setField={setField} />
                      </StepWrap>
                    )}
                    {step === 2 && (
                      <StepWrap key="2">
                        <PaymentStep
                          form={form}
                          total={total}
                          upiLink={upiLink}
                        />
                      </StepWrap>
                    )}
                    {step === 3 && (
                      <StepWrap key="3">
                        <ConfirmStep
                          form={form}
                          setField={setField}
                          total={total}
                          submitError={submitError}
                        />
                      </StepWrap>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* Footer actions */}
            {!submitted && (
              <div className="px-6 md:px-10 py-5 border-t border-ink-line bg-ink-soft shrink-0">
                <div className="flex items-center justify-between gap-4">
                  <div className="text-xs md:text-sm text-cream-dim font-mono">
                    Total:{' '}
                    <span className="text-brass font-medium text-base md:text-lg">
                      ₹{total.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    {step > 0 && (
                      <button
                        onClick={() => setStep((s) => s - 1)}
                        disabled={submitting}
                        className="text-cream-dim hover:text-cream text-xs md:text-sm uppercase tracking-[0.2em] px-3 md:px-4 py-2.5 transition-colors"
                      >
                        Back
                      </button>
                    )}
                    {step < 3 && (
                      <button
                        onClick={() => setStep((s) => s + 1)}
                        disabled={
                          (step === 0 && !canProceedStep0) ||
                          (step === 1 && !canProceedStep1) ||
                          (step === 2 && !canProceedStep2)
                        }
                        className="bg-brass text-ink px-5 md:px-7 py-2.5 md:py-3 rounded-full text-xs md:text-sm uppercase tracking-[0.2em] font-medium hover:bg-brass-light transition-colors"
                      >
                        Continue →
                      </button>
                    )}
                    {step === 3 && (
                      <button
                        onClick={handleSubmit}
                        disabled={!canSubmit || submitting}
                        className="bg-brass text-ink px-5 md:px-7 py-2.5 md:py-3 rounded-full text-xs md:text-sm uppercase tracking-[0.2em] font-medium hover:bg-brass-light transition-colors flex items-center gap-2"
                      >
                        {submitting ? (
                          <>
                            <span className="inline-block w-3 h-3 border-2 border-ink border-t-transparent rounded-full animate-spin" />
                            Submitting…
                          </>
                        ) : (
                          'Submit Booking'
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function StepWrap({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/* ───────── Step 0: Plan ───────── */
function PlanStep({ form, setField, toggleTopic, total }) {
  return (
    <div>
      <h3 className="font-display text-3xl md:text-4xl font-light text-cream mb-2 leading-tight">
        Choose your <span className="italic text-brass">reading.</span>
      </h3>
      <p className="text-cream-dim text-sm mb-8 font-body">
        Pick one. You can stack topics in the second option.
      </p>

      <div className="space-y-3 mb-8">
        <PlanCard
          active={form.plan === 'full'}
          onClick={() => setField('plan', 'full')}
          title="Full Birth Chart Reading"
          desc="A complete walk through your kundali. Lagna, dashas, key yogas, year ahead."
          price="₹1,500"
        />
        <PlanCard
          active={form.plan === 'topics'}
          onClick={() => setField('plan', 'topics')}
          title="Specific Topic Reading"
          desc="₹500 per topic. Stack as many as you need."
          price={form.plan === 'topics' && form.topics.length > 0 ? `₹${total.toLocaleString('en-IN')}` : '₹500 / each'}
        />
      </div>

      {form.plan === 'topics' && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="label">Pick the topics you want read</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {TOPICS.map((t) => {
              const checked = form.topics.includes(t.id);
              return (
                <button
                  key={t.id}
                  onClick={() => toggleTopic(t.id)}
                  className={`text-left px-4 py-3 rounded-lg border transition-all flex items-center justify-between gap-3 ${
                    checked
                      ? 'border-brass bg-brass/10 text-cream'
                      : 'border-ink-line bg-ink-soft text-cream/80 hover:border-cream-dim'
                  }`}
                >
                  <span className="text-sm">{t.label}</span>
                  <span className={`text-xs font-mono ${checked ? 'text-brass' : 'text-cream-dim'}`}>
                    {checked ? '✓' : '+'}
                  </span>
                </button>
              );
            })}
          </div>
          {form.topics.length === 0 && (
            <p className="text-xs text-cream-dim mt-3 font-body">Select at least one topic to continue.</p>
          )}
        </motion.div>
      )}
    </div>
  );
}

function PlanCard({ active, onClick, title, desc, price }) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left p-5 rounded-xl border transition-all ${
        active
          ? 'border-brass bg-brass/5'
          : 'border-ink-line bg-ink-soft hover:border-cream-dim'
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="font-display text-xl text-cream font-light mb-1">{title}</div>
          <div className="text-cream/60 text-sm">{desc}</div>
        </div>
        <div className="text-right shrink-0">
          <div className="font-display text-xl text-brass font-light">{price}</div>
        </div>
      </div>
    </button>
  );
}

/* ───────── Step 1: Details ───────── */
function DetailsStep({ form, setField }) {
  const usernameClean = form.redditUsername.replace(/^u\//, '');
  const usernameValid = /^[a-zA-Z0-9_-]{3,20}$/.test(usernameClean);
  return (
    <div>
      <h3 className="font-display text-3xl md:text-4xl font-light text-cream mb-2 leading-tight">
        Your <span className="italic text-brass">birth details.</span>
      </h3>
      <p className="text-cream-dim text-sm mb-8 font-body">
        Accuracy matters. Even 5 minutes off can change the Lagna.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="label">Name <span className="text-cream-dim normal-case">(optional)</span></label>
          <input
            type="text"
            placeholder="As you'd like to be addressed"
            value={form.name}
            onChange={(e) => setField('name', e.target.value)}
            className="field"
          />
        </div>

        <div>
          <label className="label">
            Reddit Username <span className="text-vermillion normal-case">*</span>
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-cream-dim font-mono text-sm">
              u/
            </span>
            <input
              type="text"
              placeholder="username"
              value={usernameClean}
              onChange={(e) => setField('redditUsername', e.target.value.replace(/^u\//, ''))}
              className="field pl-10"
              required
            />
          </div>
          {form.redditUsername.length > 0 && !usernameValid && (
            <p className="text-xs text-vermillion mt-1.5">
              3–20 characters, letters / numbers / underscore / hyphen only
            </p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="label">Email <span className="text-cream-dim normal-case">(optional)</span></label>
          <input
            type="email"
            placeholder="for backup contact"
            value={form.email}
            onChange={(e) => setField('email', e.target.value)}
            className="field"
          />
        </div>

        <div>
          <label className="label">
            Gender <span className="text-vermillion normal-case">*</span>
          </label>
          <select
            value={form.gender}
            onChange={(e) => setField('gender', e.target.value)}
            className="field"
            required
          >
            <option value="">Select…</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
            <option value="Prefer not to say">Prefer not to say</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className="label">
            Date of Birth <span className="text-vermillion normal-case">*</span>
          </label>
          <input
            type="date"
            max={new Date().toISOString().split('T')[0]}
            value={form.dob}
            onChange={(e) => setField('dob', e.target.value)}
            className="field"
            required
          />
        </div>

        <div>
          <label className="label">
            Exact Time of Birth <span className="text-vermillion normal-case">*</span>
          </label>
          <input
            type="time"
            value={form.tob}
            onChange={(e) => setField('tob', e.target.value)}
            className="field"
            required
          />
        </div>
      </div>

      <div className="mb-4">
        <label className="label">
          Place of Birth <span className="text-vermillion normal-case">*</span>
        </label>
        <input
          type="text"
          placeholder="City, State, Country (e.g. Kolkata, West Bengal, India)"
          value={form.pob}
          onChange={(e) => setField('pob', e.target.value)}
          className="field"
          required
        />
      </div>

      <div className="mb-4">
        <label className="label">
          Context for the Reading <span className="text-vermillion normal-case">*</span>
        </label>
        <textarea
          placeholder="Tell me what's going on — current life situation, what's been weighing on you, anything relevant for the analysis. The more honest the better."
          value={form.context}
          onChange={(e) => setField('context', e.target.value)}
          className="field min-h-[120px]"
          required
        />
        <p className="text-xs text-cream-dim mt-1.5">
          Min. 10 characters. This helps me focus the reading on what matters to you.
        </p>
      </div>

      <div>
        <label className="label">Specific Questions <span className="text-cream-dim normal-case">(optional)</span></label>
        <textarea
          placeholder="Anything specific you want answered in the reading?"
          value={form.questions}
          onChange={(e) => setField('questions', e.target.value)}
          className="field"
        />
      </div>
    </div>
  );
}

/* ───────── Step 2: Payment ───────── */
function PaymentStep({ form, total, upiLink }) {
  const [copied, setCopied] = useState('');

  const copy = (text, key) => {
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(key);
      setTimeout(() => setCopied(''), 1500);
    });
  };

  return (
    <div>
      <h3 className="font-display text-3xl md:text-4xl font-light text-cream mb-2 leading-tight">
        Complete <span className="italic text-brass">payment.</span>
      </h3>
      <p className="text-cream-dim text-sm mb-8 font-body">
        Pay via any UPI app (PhonePe, GPay, Paytm, BHIM…). On the next step, you'll enter the UTR from your payment app.
      </p>

      {/* Amount */}
      <div className="bg-ink-soft border border-ink-line rounded-xl p-6 mb-6 flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-[0.25em] text-cream-dim font-mono mb-1">
            Amount to Pay
          </div>
          <div className="font-display text-4xl text-brass font-light">
            ₹{total.toLocaleString('en-IN')}
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs uppercase tracking-[0.25em] text-cream-dim font-mono mb-1">
            Reference
          </div>
          <div className="font-mono text-sm text-cream">u/{form.redditUsername || '—'}</div>
        </div>
      </div>

      {/* QR + UPI */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {/* QR */}
        <div className="bg-cream rounded-xl p-5 flex flex-col items-center">
          <div className="text-[10px] uppercase tracking-[0.25em] text-ink/60 font-mono mb-3">
            Scan to Pay
          </div>
          <div className="relative w-full aspect-square max-w-[240px]">
            <Image
              src="/upi-qr.jpg"
              alt="UPI Payment QR Code"
              fill
              className="object-contain"
              sizes="240px"
              priority
            />
          </div>
        </div>

        {/* UPI / mobile */}
        <div className="bg-ink-soft border border-ink-line rounded-xl p-5 flex flex-col">
          <div className="text-[10px] uppercase tracking-[0.25em] text-cream-dim font-mono mb-3">
            Or Pay Manually
          </div>

          <CopyRow label="UPI ID" value={UPI_ID} copied={copied === 'upi'} onCopy={() => copy(UPI_ID, 'upi')} />
          <CopyRow label="Account No." value={ACCOUNT_NUMBER} copied={copied === 'acc'} onCopy={() => copy(ACCOUNT_NUMBER, 'acc')} />
          <CopyRow label="IFSC" value={IFSC} copied={copied === 'ifsc'} onCopy={() => copy(IFSC, 'ifsc')} />

          {/* Mobile deep link */}
          <a
            href={upiLink}
            className="md:hidden mt-4 block text-center bg-brass text-ink py-3 rounded-full text-xs uppercase tracking-[0.2em] font-medium"
          >
            Open UPI App →
          </a>
        </div>
      </div>

      <div className="bg-vermillion/5 border border-vermillion/30 rounded-xl p-4 text-sm text-cream/80 leading-relaxed">
        <strong className="text-vermillion">Important:</strong> After paying, copy the <span className="text-brass font-mono">UTR / Reference Number</span> shown in your UPI app's success screen. You'll need it on the next step. Your booking is only confirmed once the UTR is matched against the received payment.
      </div>
    </div>
  );
}

function CopyRow({ label, value, copied, onCopy }) {
  return (
    <div className="py-2 border-b border-ink-line last:border-b-0">
      <div className="text-[10px] uppercase tracking-[0.25em] text-cream-dim font-mono mb-1">
        {label}
      </div>
      <div className="flex items-center justify-between gap-2">
        <code className="font-mono text-sm text-cream truncate">{value}</code>
        <button
          onClick={onCopy}
          className="text-xs uppercase tracking-[0.2em] font-mono text-brass hover:text-brass-light shrink-0 px-2 py-1"
        >
          {copied ? '✓ Copied' : 'Copy'}
        </button>
      </div>
    </div>
  );
}

/* ───────── Step 3: Confirm ───────── */
function ConfirmStep({ form, setField, total, submitError }) {
  return (
    <div>
      <h3 className="font-display text-3xl md:text-4xl font-light text-cream mb-2 leading-tight">
        Confirm your <span className="italic text-brass">payment.</span>
      </h3>
      <p className="text-cream-dim text-sm mb-8 font-body">
        Enter the UTR from your UPI app. This is what verifies your booking.
      </p>

      <div className="mb-5">
        <label className="label">
          UTR / Reference Number <span className="text-vermillion normal-case">*</span>
        </label>
        <input
          type="text"
          inputMode="numeric"
          placeholder="e.g. 412345678901"
          value={form.utr}
          onChange={(e) => setField('utr', e.target.value.replace(/[^a-zA-Z0-9]/g, ''))}
          className="field font-mono tracking-wider"
          required
        />
        <p className="text-xs text-cream-dim mt-1.5">
          You'll find this in your UPI app's transaction details — usually 12 digits, sometimes labelled "UPI Ref ID" or "Transaction ID".
        </p>
      </div>

      <div className="mb-5">
        <label className="label">
          Anything else? <span className="text-cream-dim normal-case">(optional)</span>
        </label>
        <textarea
          placeholder="Feedback, special requests, or anything you want to add"
          value={form.feedback}
          onChange={(e) => setField('feedback', e.target.value)}
          className="field"
        />
      </div>

      {/* Summary */}
      <div className="bg-ink-soft border border-ink-line rounded-xl p-5 space-y-3">
        <div className="text-[10px] uppercase tracking-[0.25em] text-cream-dim font-mono mb-2">
          Booking Summary
        </div>
        <SummaryRow label="Plan" value={form.plan === 'full' ? 'Full Birth Chart Reading' : 'Specific Topic Reading'} />
        {form.plan === 'topics' && (
          <SummaryRow label="Topics" value={form.topics.map((id) => TOPICS.find((t) => t.id === id)?.label).filter(Boolean).join(', ') || '—'} />
        )}
        <SummaryRow label="Reddit" value={`u/${form.redditUsername.replace(/^u\//, '')}`} mono />
        <SummaryRow label="Born" value={`${form.dob || '—'} · ${form.tob || '—'}`} mono />
        <SummaryRow label="Place" value={form.pob || '—'} />
        <div className="pt-3 border-t border-ink-line flex items-center justify-between">
          <span className="text-xs uppercase tracking-[0.2em] text-cream-dim font-mono">Total Paid</span>
          <span className="font-display text-2xl text-brass font-light">₹{total.toLocaleString('en-IN')}</span>
        </div>
      </div>

      {submitError && (
        <div className="mt-5 bg-vermillion/10 border border-vermillion/40 rounded-xl p-4 text-sm text-cream">
          <strong className="text-vermillion">Submission failed.</strong> {submitError}
        </div>
      )}
    </div>
  );
}

function SummaryRow({ label, value, mono }) {
  return (
    <div className="flex items-start justify-between gap-4 text-sm">
      <span className="text-cream-dim shrink-0">{label}</span>
      <span className={`text-cream text-right ${mono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}

/* ───────── Success ───────── */
function SuccessScreen({ form, total, onClose }) {
  return (
    <div className="px-6 md:px-10 py-12 md:py-16 text-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="w-20 h-20 mx-auto mb-8 rounded-full border border-brass flex items-center justify-center"
      >
        <span className="text-brass text-3xl">✓</span>
      </motion.div>

      <motion.h3
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.6 }}
        className="font-display text-3xl md:text-4xl font-light text-cream mb-3 leading-tight"
      >
        Booking <span className="italic text-brass">received.</span>
      </motion.h3>

      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="text-cream/80 max-w-lg mx-auto mb-8 leading-relaxed"
      >
        Your details and UTR have been logged. I'll verify the payment and start
        on your chart shortly. The reading will arrive at{' '}
        <span className="text-brass font-mono">u/{form.redditUsername.replace(/^u\//, '')}</span>{' '}
        via Reddit DM, typically within 24–48 hours.
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="bg-ink-soft border border-ink-line rounded-xl p-5 max-w-md mx-auto mb-8 text-left"
      >
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cream-dim font-mono">UTR</span>
          <span className="font-mono text-cream text-sm">{form.utr}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-[0.25em] text-cream-dim font-mono">Amount</span>
          <span className="font-display text-brass">₹{total.toLocaleString('en-IN')}</span>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="flex flex-col sm:flex-row items-center justify-center gap-3"
      >
        <a
          href="https://www.reddit.com/u/invincible-xd"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-brass text-ink px-6 py-3 rounded-full text-xs uppercase tracking-[0.2em] font-medium hover:bg-brass-light transition-colors"
        >
          Visit u/invincible-xd →
        </a>
        <button
          onClick={onClose}
          className="text-cream-dim hover:text-cream text-xs uppercase tracking-[0.2em] px-6 py-3 transition-colors"
        >
          Close
        </button>
      </motion.div>
    </div>
  );
}
