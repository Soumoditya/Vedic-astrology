'use client';
import { motion } from 'framer-motion';

export default function Hero({ onBookClick }) {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Constellation background */}
      <div className="absolute inset-0 constellation opacity-50" />

      {/* Cosmic ring decoration */}
      <div className="absolute right-[-20%] top-1/2 -translate-y-1/2 w-[120vh] h-[120vh] pointer-events-none opacity-30 md:opacity-50 md:right-[-15%]">
        <motion.div
          initial={{ opacity: 0, scale: 0.92, rotate: -8 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ duration: 2.4, ease: [0.16, 1, 0.3, 1] }}
          className="w-full h-full"
        >
          <svg viewBox="0 0 800 800" className="w-full h-full animate-slow-rotate">
            {/* Outer ring with degree marks */}
            <circle cx="400" cy="400" r="380" fill="none" stroke="#C9A961" strokeWidth="0.5" opacity="0.3" />
            <circle cx="400" cy="400" r="340" fill="none" stroke="#C9A961" strokeWidth="0.3" opacity="0.5" />
            <circle cx="400" cy="400" r="280" fill="none" stroke="#C9A961" strokeWidth="0.5" opacity="0.4" />
            <circle cx="400" cy="400" r="220" fill="none" stroke="#C9A961" strokeWidth="0.3" opacity="0.3" />

            {/* 12 house divisions */}
            {Array.from({ length: 12 }).map((_, i) => {
              const angle = (i * 30 * Math.PI) / 180;
              const x1 = 400 + 220 * Math.cos(angle);
              const y1 = 400 + 220 * Math.sin(angle);
              const x2 = 400 + 380 * Math.cos(angle);
              const y2 = 400 + 380 * Math.sin(angle);
              return (
                <line
                  key={i}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="#C9A961"
                  strokeWidth="0.5"
                  opacity="0.4"
                />
              );
            })}

            {/* 360 small ticks */}
            {Array.from({ length: 72 }).map((_, i) => {
              const angle = (i * 5 * Math.PI) / 180;
              const x1 = 400 + 378 * Math.cos(angle);
              const y1 = 400 + 378 * Math.sin(angle);
              const x2 = 400 + 372 * Math.cos(angle);
              const y2 = 400 + 372 * Math.sin(angle);
              return (
                <line
                  key={i}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="#C9A961"
                  strokeWidth="0.5"
                  opacity="0.5"
                />
              );
            })}

            {/* Center bindu */}
            <circle cx="400" cy="400" r="3" fill="#C9A961" opacity="0.6" />
          </svg>
        </motion.div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 w-full pt-24 pb-12">
        <div className="grid grid-cols-12 gap-6">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="col-span-12 flex items-center gap-3 mb-2"
          >
            <span className="block w-12 h-px bg-brass" />
            <span className="text-xs uppercase tracking-[0.3em] text-brass font-mono">
              Jyotiṣa · ज्योतिष
            </span>
          </motion.div>

          {/* Main heading */}
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="col-span-12 md:col-span-10 font-display font-light text-cream leading-[0.95] tracking-tightest text-[clamp(2.8rem,9vw,7.5rem)]"
            style={{ fontVariationSettings: '"opsz" 144, "SOFT" 50' }}
          >
            Birth charts<br />
            <span className="italic font-extralight text-brass">read carefully,</span><br />
            not generically.
          </motion.h1>

          {/* Subline */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="col-span-12 md:col-span-6 mt-8 text-cream/80 text-lg md:text-xl leading-relaxed font-light"
          >
            Personalised Vedic astrology consultations grounded in classical
            Jyotiṣa. No daily horoscopes, no copy-paste predictions — just
            careful analysis of your unique kundali.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="col-span-12 mt-10 flex flex-wrap items-center gap-4"
          >
            <button
              onClick={onBookClick}
              className="group relative inline-flex items-center gap-3 bg-brass text-ink px-7 py-4 rounded-full font-medium text-sm uppercase tracking-[0.2em] hover:bg-brass-light transition-all duration-300 hover:gap-5"
            >
              Book a Reading
              <span className="text-base group-hover:translate-x-1 transition-transform">→</span>
            </button>

            <a
              href="#services"
              className="text-cream/70 hover:text-brass text-sm uppercase tracking-[0.2em] transition-colors px-4 py-4"
            >
              See pricing
            </a>
          </motion.div>

          {/* Footer info — bottom of hero */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.4 }}
            className="col-span-12 mt-20 md:mt-32 grid grid-cols-2 md:grid-cols-4 gap-6 pt-8 border-t border-ink-line"
          >
            <Stat label="Reading depth" value="Classical" />
            <Stat label="Delivery" value="Reddit DM" />
            <Stat label="Turnaround" value="24–48 hrs" />
            <Stat label="Payment" value="UPI · India" />
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-cream-dim text-[10px] uppercase tracking-[0.3em] flex flex-col items-center gap-2"
      >
        <span>Scroll</span>
        <span className="block w-px h-8 bg-gradient-to-b from-brass to-transparent" />
      </motion.div>
    </section>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-[0.25em] text-cream-dim mb-1 font-mono">{label}</div>
      <div className="font-display text-xl text-cream font-light">{value}</div>
    </div>
  );
}
