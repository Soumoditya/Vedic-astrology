'use client';
import { motion } from 'framer-motion';

const PRESENCE = [
  {
    platform: 'Reddit',
    handle: 'u/invincible-xd',
    href: 'https://www.reddit.com/u/invincible-xd',
    desc: 'Active astrologer on Reddit. Public post and comment history.',
  },
  {
    platform: 'Subreddit',
    handle: 'r/Vedic_astro',
    href: 'https://www.reddit.com/r/Vedic_astro',
    desc: 'Community I run, focused on serious Vedic astrology discussion.',
  },
  {
    platform: 'Instagram',
    handle: '@vedic.astrologey',
    href: 'https://instagram.com/vedic.astrologey',
    desc: 'Birth chart insights and Jyotiṣa concepts explained simply.',
  },
];

export default function Trust() {
  return (
    <section id="presence" className="relative py-32 md:py-40 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-12 gap-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="col-span-12 md:col-span-3"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="block w-8 h-px bg-brass" />
              <span className="text-xs uppercase tracking-[0.3em] text-brass font-mono">
                03 / Presence
              </span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="col-span-12 md:col-span-9"
          >
            <h2 className="font-display text-4xl md:text-6xl font-light leading-[1.05] tracking-tight mb-6">
              Verifiable presence,<br />
              <span className="italic text-brass font-extralight">not a pseudonym.</span>
            </h2>
            <p className="text-cream/70 text-lg max-w-2xl leading-relaxed">
              Before you book, check the public work. The accounts below are
              active and verifiable — read posts, comments, replies, see how
              charts are actually read.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {PRESENCE.map((p, i) => (
            <motion.a
              key={p.platform}
              href={p.href}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.7, delay: i * 0.1 }}
              className="group bg-ink-soft border border-ink-line rounded-2xl p-8 hover:border-brass/40 transition-all duration-500 hover:-translate-y-1"
            >
              <div className="flex items-start justify-between mb-8">
                <span className="text-xs uppercase tracking-[0.3em] text-cream-dim font-mono">
                  {p.platform}
                </span>
                <span className="text-brass text-xl group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform">
                  ↗
                </span>
              </div>
              <div className="font-display text-2xl md:text-3xl font-light text-cream mb-3 leading-tight break-all">
                {p.handle}
              </div>
              <p className="text-cream/60 text-sm leading-relaxed">
                {p.desc}
              </p>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
