'use client';
import { motion, useScroll, useTransform } from 'framer-motion';

export default function Nav({ onBookClick }) {
  const { scrollY } = useScroll();
  const bg = useTransform(scrollY, [0, 100], ['rgba(11, 14, 20, 0)', 'rgba(11, 14, 20, 0.8)']);
  const border = useTransform(scrollY, [0, 100], ['rgba(37, 43, 59, 0)', 'rgba(37, 43, 59, 1)']);

  return (
    <motion.nav
      style={{ backgroundColor: bg, borderBottom: '1px solid', borderColor: border }}
      className="fixed top-0 left-0 right-0 z-40 backdrop-blur-md transition-all"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-4 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-3">
          <span className="font-display text-2xl text-brass font-light">ज्योतिष</span>
          <span className="text-cream-dim text-[10px] uppercase tracking-[0.25em] font-mono hidden sm:block">
            Vedic Astrology
          </span>
        </a>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-7">
            {[
              ['Services', '#services'],
              ['Process', '#process'],
              ['FAQ', '#faq'],
            ].map(([label, href]) => (
              <a
                key={href}
                href={href}
                className="text-cream/70 hover:text-brass text-[11px] uppercase tracking-[0.25em] font-mono transition-colors"
              >
                {label}
              </a>
            ))}
          </div>

          <button
            onClick={onBookClick}
            className="bg-brass text-ink px-4 md:px-5 py-2 md:py-2.5 rounded-full text-[10px] md:text-xs uppercase tracking-[0.2em] font-medium hover:bg-brass-light transition-colors"
          >
            Book
          </button>
        </div>
      </div>
    </motion.nav>
  );
}
