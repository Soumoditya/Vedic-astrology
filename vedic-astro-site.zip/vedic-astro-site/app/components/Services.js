'use client';
import { motion } from 'framer-motion';

export const TOPICS = [
  { id: 'career', label: 'Career & Profession' },
  { id: 'marriage', label: 'Marriage & Relationships' },
  { id: 'finance', label: 'Wealth & Finance' },
  { id: 'health', label: 'Health & Vitality' },
  { id: 'education', label: 'Education & Learning' },
  { id: 'family', label: 'Family Matters' },
  { id: 'travel', label: 'Foreign Travel & Settlement' },
  { id: 'spiritual', label: 'Spiritual Path' },
  { id: 'litigation', label: 'Legal & Disputes' },
  { id: 'children', label: 'Children & Progeny' },
];

export default function Services({ onBookClick }) {
  return (
    <section id="services" className="relative py-32 md:py-40 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        {/* Section heading */}
        <div className="grid grid-cols-12 gap-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="col-span-12 md:col-span-3"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="block w-8 h-px bg-brass" />
              <span className="text-xs uppercase tracking-[0.3em] text-brass font-mono">
                01 / Services
              </span>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="col-span-12 md:col-span-9 font-display text-4xl md:text-6xl font-light leading-[1.05] tracking-tight"
          >
            Two ways to read<br />
            <span className="italic text-brass font-extralight">your chart.</span>
          </motion.h2>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Full Chart */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.8 }}
            className="group relative bg-gradient-to-br from-ink-soft to-ink p-8 md:p-12 rounded-2xl border border-ink-line hover:border-brass/40 transition-all duration-500 overflow-hidden"
          >
            {/* Decorative number */}
            <div className="absolute top-6 right-8 font-display text-[6rem] text-ink-mid font-light leading-none select-none">
              I
            </div>

            <div className="relative">
              <div className="text-xs uppercase tracking-[0.3em] text-brass font-mono mb-6">
                Full Reading
              </div>
              <h3 className="font-display text-3xl md:text-4xl font-light text-cream leading-tight mb-2">
                Full Birth Chart<br />
                <span className="italic">Reading</span>
              </h3>

              <div className="flex items-baseline gap-2 my-8">
                <span className="font-display text-6xl md:text-7xl font-light text-brass">
                  ₹1,500
                </span>
              </div>

              <p className="text-cream/70 leading-relaxed mb-8">
                A complete walk through your kundali — Lagna, planetary
                placements, dashas, key yogas, strengths, and challenges.
                Best if you've never had a reading or want the full picture.
              </p>

              <div className="space-y-3 mb-10">
                {[
                  'Complete birth chart analysis',
                  'Current Mahādaśā / Antardaśā context',
                  'Strengths, doshas, and yogas in your chart',
                  'Practical guidance for the year ahead',
                  'Detailed written reading via Reddit DM',
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3 text-sm text-cream/80">
                    <span className="text-brass mt-0.5">◇</span>
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => onBookClick('full')}
                className="w-full bg-brass text-ink py-4 rounded-full font-medium text-sm uppercase tracking-[0.2em] hover:bg-brass-light transition-colors"
              >
                Book Full Reading
              </button>
            </div>
          </motion.div>

          {/* Topic-based */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-50px' }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="group relative bg-ink-soft p-8 md:p-12 rounded-2xl border border-ink-line hover:border-brass/40 transition-all duration-500 overflow-hidden"
          >
            <div className="absolute top-6 right-8 font-display text-[6rem] text-ink-mid font-light leading-none select-none">
              II
            </div>

            <div className="relative">
              <div className="text-xs uppercase tracking-[0.3em] text-brass font-mono mb-6">
                Focused Reading
              </div>
              <h3 className="font-display text-3xl md:text-4xl font-light text-cream leading-tight mb-2">
                Specific Topic<br />
                <span className="italic">Reading</span>
              </h3>

              <div className="flex items-baseline gap-3 my-8">
                <span className="font-display text-6xl md:text-7xl font-light text-brass">
                  ₹500
                </span>
                <span className="text-cream-dim text-sm font-mono">/ topic</span>
              </div>

              <p className="text-cream/70 leading-relaxed mb-6">
                Pick only what you need. Stack topics for a deeper read.
                Career + Marriage = ₹1,000. Career + Marriage + Health = ₹1,500.
              </p>

              <div className="flex flex-wrap gap-2 mb-10">
                {TOPICS.map((topic) => (
                  <span
                    key={topic.id}
                    className="text-xs px-3 py-1.5 rounded-full border border-ink-line text-cream/70 font-body"
                  >
                    {topic.label}
                  </span>
                ))}
              </div>

              <button
                onClick={() => onBookClick('topics')}
                className="w-full bg-transparent border border-brass text-brass py-4 rounded-full font-medium text-sm uppercase tracking-[0.2em] hover:bg-brass hover:text-ink transition-all"
              >
                Choose Topics
              </button>
            </div>
          </motion.div>
        </div>

        {/* Note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-center text-cream-dim text-sm mt-10 font-body"
        >
          All payments via UPI · Reading delivered through Reddit DM within 24–48 hours after payment verification.
        </motion.p>
      </div>
    </section>
  );
}
