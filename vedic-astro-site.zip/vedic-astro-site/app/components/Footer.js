'use client';
import { motion } from 'framer-motion';

export default function Footer({ onBookClick }) {
  const year = new Date().getFullYear();
  return (
    <footer className="relative pt-32 pb-10 px-6 md:px-12 border-t border-ink-line overflow-hidden">
      {/* Decorative ॐ */}
      <div className="absolute -top-40 left-1/2 -translate-x-1/2 font-display text-[24rem] text-ink-soft select-none pointer-events-none leading-none">
        ॐ
      </div>

      <div className="relative max-w-7xl mx-auto">
        {/* Final CTA */}
        <div className="text-center mb-24">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="font-display text-4xl md:text-6xl font-light leading-[1.05] mb-8 max-w-3xl mx-auto"
          >
            Ready to read<br />
            <span className="italic text-brass font-extralight">your chart?</span>
          </motion.h2>
          <motion.button
            onClick={() => onBookClick && onBookClick()}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="inline-flex items-center gap-3 bg-brass text-ink px-8 py-4 rounded-full font-medium text-sm uppercase tracking-[0.2em] hover:bg-brass-light transition-all hover:gap-5"
          >
            Book a Reading
            <span className="text-base">→</span>
          </motion.button>
        </div>

        {/* Footer links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pb-12 border-b border-ink-line">
          <FooterCol title="Pages">
            <FooterLink href="#services">Services</FooterLink>
            <FooterLink href="#process">Process</FooterLink>
            <FooterLink href="#presence">Presence</FooterLink>
            <FooterLink href="#faq">FAQ</FooterLink>
          </FooterCol>

          <FooterCol title="Reddit">
            <FooterLink href="https://www.reddit.com/u/invincible-xd" external>
              u/invincible-xd
            </FooterLink>
            <FooterLink href="https://www.reddit.com/r/Vedic_astro" external>
              r/Vedic_astro
            </FooterLink>
          </FooterCol>

          <FooterCol title="Instagram">
            <FooterLink href="https://instagram.com/vedic.astrologey" external>
              @vedic.astrologey
            </FooterLink>
          </FooterCol>

          <FooterCol title="Payments">
            <li className="text-cream-dim text-sm">UPI · India only</li>
            <li className="text-cream-dim text-sm">Manual UTR verification</li>
          </FooterCol>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pt-8">
          <div className="flex items-center gap-3">
            <span className="font-display text-2xl text-brass font-light">ज्योतिष</span>
            <span className="text-cream-dim text-xs font-mono">
              Vedic Astrology Consultation
            </span>
          </div>
          <div className="text-cream-dim text-xs font-mono">
            © {year} · For consultation purposes · Not a substitute for medical, legal, or financial advice.
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, children }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-[0.3em] text-cream-dim mb-4 font-mono">
        {title}
      </div>
      <ul className="space-y-2">{children}</ul>
    </div>
  );
}

function FooterLink({ href, external, children }) {
  return (
    <li>
      <a
        href={href}
        target={external ? '_blank' : undefined}
        rel={external ? 'noopener noreferrer' : undefined}
        className="text-cream/80 hover:text-brass text-sm transition-colors"
      >
        {children}
      </a>
    </li>
  );
}
