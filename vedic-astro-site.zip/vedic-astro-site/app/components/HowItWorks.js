'use client';
import { motion } from 'framer-motion';

const STEPS = [
  {
    n: '01',
    title: 'Book & Pay',
    body: 'Pick your plan, fill in your birth details and questions, then pay via UPI. Enter the UTR (transaction reference) from your UPI app to confirm.',
  },
  {
    n: '02',
    title: 'Verification',
    body: 'I match the UTR with the payment received in my account. This is usually quick — a few hours during the day, longer overnight.',
  },
  {
    n: '03',
    title: 'Chart Analysis',
    body: 'Your kundali is cast and studied carefully — planetary placements, dashas, key yogas, the questions you raised. No templates, no auto-generated reports.',
  },
  {
    n: '04',
    title: 'Reading Delivered',
    body: 'A detailed written reading is sent to your Reddit username via DM, typically within 24–48 hours of payment verification. You can ask one round of follow-up questions.',
  },
];

export default function HowItWorks() {
  return (
    <section id="process" className="relative py-32 md:py-40 px-6 md:px-12 bg-ink-soft/40">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-12 gap-6 mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="col-span-12 md:col-span-3"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="block w-8 h-px bg-brass" />
              <span className="text-xs uppercase tracking-[0.3em] text-brass font-mono">
                02 / Process
              </span>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="col-span-12 md:col-span-9 font-display text-4xl md:text-6xl font-light leading-[1.05] tracking-tight"
          >
            How a consultation<br />
            <span className="italic text-brass font-extralight">actually works.</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-ink-line">
          {STEPS.map((step, i) => (
            <motion.div
              key={step.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.8, delay: i * 0.1 }}
              className="bg-ink p-8 md:p-12 group hover:bg-ink-soft transition-colors duration-500"
            >
              <div className="flex items-baseline gap-6 mb-6">
                <span className="font-display text-5xl text-brass font-light">
                  {step.n}
                </span>
                <span className="block flex-1 h-px bg-ink-line group-hover:bg-brass/40 transition-colors" />
              </div>
              <h3 className="font-display text-2xl md:text-3xl font-light text-cream mb-4 leading-tight">
                {step.title}
              </h3>
              <p className="text-cream/70 leading-relaxed">{step.body}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
