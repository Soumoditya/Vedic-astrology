import './globals.css';

export const metadata = {
  title: 'Vedic Astrology Consultation — Birth Chart Readings',
  description:
    'Personalised birth chart analysis grounded in classical Jyotiṣa. Book a full reading or focused topic consultation.',
  openGraph: {
    title: 'Vedic Astrology Consultation',
    description: 'Personalised birth chart analysis grounded in classical Jyotiṣa.',
    type: 'website',
  },
  robots: { index: true, follow: true },
};

export const viewport = {
  themeColor: '#0B0E14',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght,SOFT@0,9..144,100..900,0..100;1,9..144,100..900,0..100&family=Manrope:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-ink text-cream font-body antialiased">{children}</body>
    </html>
  );
}
