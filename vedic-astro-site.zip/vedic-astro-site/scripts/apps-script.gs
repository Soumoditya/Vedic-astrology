/**
 * Vedic Astro Booking — Google Apps Script
 * ────────────────────────────────────────────
 * This script receives booking submissions from the website and writes
 * them as rows into a Google Sheet, then sends you an email notification.
 *
 * Setup:
 *   1) Create a new Google Sheet, name it whatever you want
 *      (e.g. "Astro Bookings").
 *   2) Open Extensions → Apps Script.
 *   3) Delete the default code, paste this entire file in.
 *   4) Update NOTIFY_EMAIL below to your own email.
 *   5) Click "Save" (disk icon), name the project "Astro Booking API".
 *   6) Click "Deploy" → "New deployment" → gear icon → choose "Web app".
 *   7) Settings:
 *        Description: "Astro Booking endpoint"
 *        Execute as: Me (your account)
 *        Who has access: Anyone
 *      Click "Deploy". Authorize when prompted.
 *   8) Copy the "Web app URL" — paste it as NEXT_PUBLIC_APPS_SCRIPT_URL
 *      in your Vercel environment variables.
 *
 * Whenever you change this script, redeploy as a NEW VERSION
 * (Deploy → Manage deployments → pencil → New version).
 */

const NOTIFY_EMAIL = 'your-email@example.com'; // ← change this
const SHEET_NAME = 'Bookings';

const HEADERS = [
  'Timestamp (IST)',
  'Status',
  'Plan',
  'Topics',
  'Amount (₹)',
  'UTR',
  'Reddit Username',
  'Name',
  'Email',
  'Gender',
  'DOB',
  'Time of Birth',
  'Place of Birth',
  'Context',
  'Specific Questions',
  'Feedback',
  'Submitted ISO',
];

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const sheet = getOrCreateSheet_();

    const istTime = Utilities.formatDate(
      new Date(),
      'Asia/Kolkata',
      'yyyy-MM-dd HH:mm:ss'
    );

    sheet.appendRow([
      istTime,
      data.status || 'Pending Verification',
      data.plan || '',
      Array.isArray(data.topics) ? data.topics.join(', ') : (data.topics || ''),
      data.amount || 0,
      data.utr || '',
      data.redditUsername || '',
      data.name || '',
      data.email || '',
      data.gender || '',
      data.dob || '',
      data.tob || '',
      data.pob || '',
      data.context || '',
      data.questions || '',
      data.feedback || '',
      data.timestamp || new Date().toISOString(),
    ]);

    // Email notification
    try {
      if (NOTIFY_EMAIL && NOTIFY_EMAIL !== 'your-email@example.com') {
        const subject = `New Astro Booking · ₹${data.amount} · u/${data.redditUsername}`;
        const body = [
          `New booking received at ${istTime} IST.`,
          ``,
          `Plan: ${data.plan}`,
          (data.topics && data.topics.length) ? `Topics: ${Array.isArray(data.topics) ? data.topics.join(', ') : data.topics}` : '',
          `Amount: ₹${data.amount}`,
          `UTR: ${data.utr}`,
          ``,
          `Reddit: u/${data.redditUsername}`,
          data.name ? `Name: ${data.name}` : '',
          data.email ? `Email: ${data.email}` : '',
          `Gender: ${data.gender}`,
          `DOB: ${data.dob} at ${data.tob}`,
          `Place: ${data.pob}`,
          ``,
          `Context:`,
          data.context,
          ``,
          data.questions ? `Questions:\n${data.questions}\n` : '',
          data.feedback ? `Feedback:\n${data.feedback}` : '',
        ].filter(Boolean).join('\n');

        MailApp.sendEmail(NOTIFY_EMAIL, subject, body);
      }
    } catch (mailErr) {
      // Don't fail the whole request if email fails
      console.error('Mail error:', mailErr);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    console.error(err);
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  // Health check endpoint
  return ContentService
    .createTextOutput(JSON.stringify({ status: 'ok', service: 'astro-booking' }))
    .setMimeType(ContentService.MimeType.JSON);
}

function getOrCreateSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
  }
  // Initialize headers if empty
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    const headerRange = sheet.getRange(1, 1, 1, HEADERS.length);
    headerRange.setFontWeight('bold');
    headerRange.setBackground('#0B0E14');
    headerRange.setFontColor('#C9A961');
    sheet.setFrozenRows(1);
    // Reasonable column widths
    sheet.setColumnWidth(1, 160);
    sheet.setColumnWidth(2, 130);
    sheet.setColumnWidth(3, 200);
    sheet.setColumnWidth(4, 220);
    sheet.setColumnWidth(5, 90);
    sheet.setColumnWidth(6, 140);
    sheet.setColumnWidth(7, 140);
    sheet.setColumnWidth(14, 320); // Context
    sheet.setColumnWidth(15, 240);
    sheet.setColumnWidth(16, 240);
  }
  return sheet;
}
