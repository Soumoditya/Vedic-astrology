/** @type {import('tailwindcss').Config} */
export default {
  content: ["./app/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: '#0B0E14',
          soft: '#13171F',
          mid: '#1C2230',
          line: '#252B3B',
        },
        cream: {
          DEFAULT: '#F2EBD8',
          soft: '#E8DDC2',
          dim: '#A8A192',
        },
        brass: {
          DEFAULT: '#C9A961',
          light: '#E0C684',
          deep: '#9A7E3F',
        },
        vermillion: '#C73E1D',
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        body: ['Manrope', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      letterSpacing: {
        tightest: '-0.04em',
      },
    },
  },
  plugins: [],
};
